EnronQA test pilot drawn from MichaelR207/enron_qa_0922 at
c0b3a9190fd970e83cfbe7d399a08860e43e221e. Original benchmark: Michael J. Ryan,
Danmei Xu, Chris Nivera and Daniel Campos, https://arxiv.org/abs/2505.00263.
Local machine translation: Helsinki-NLP/opus-mt-en-ru, bb09c99d180016eac6819df3dae68edb1690fdee.
Each question and its published rephrasing points to its source message using the
original path. Additional relevant messages were not judged. The project eval reads queries_dev.jsonl;
every record in this pilot
comes from the EnronQA test split. Fields doc_dt=null and query_date=2004-01-01
are adapter conventions. No receipt-day constraint is applied.
